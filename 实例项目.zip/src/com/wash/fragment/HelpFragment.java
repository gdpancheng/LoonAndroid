package com.wash.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;

import com.android.pc.ioc.app.Ioc;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.util.Handler_Inject;
import com.android.pc.util.Handler_System;
import com.wash.activity.R;
import com.wash.application.App;
import com.wash.view.FlowTextView;
import com.wash.view.FlowTextView.OnLinkClickListener;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class HelpFragment extends BaseFragment {

	private static String markup = "<!--PSTYLE=WBDY_Web bodytext--><p>The Irish funnyman&#8217;s stand-up <b>show</b> <i>starts</i> at 8pm. The show is called Craic Dealer and tickets cost &#163;21 from <a href=\"http://kings-southsea.com\">kings-southsea.com</a> or (023) 9282 8282.</p><p>Botox, the might of motherhood and the challenges of childlessness all go under the microscope with Motherland, which is at The Point, Eastleigh, tonight. Tickets cost &#163;10 to &#163;12 from (023) 9265 2333 or <a href=\"http://thepointeastleigh.co.uk\">thepointeastleigh.co.uk</a></p><p>Portsmouth Guildhall launches a new Live Lounge concert series today with a show from Barbara Jungr. The new concerts will feature top artists in the relaxed and intimate atmosphere of the Caf&#233; Guildhall. Tickets: &#163;12/&#163;10 from (023) 9282 4355 or <a href=\"http://portsmouthguildhall.org.uk\">portsmouthguildhall.org.uk</a></p>";

	@InjectView
	private FlowTextView tv;
	@InjectView
	private ScrollView content_sl;
	private View view;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		view = inflater.inflate(R.layout.activity_help, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}

	@InjectInit
	private void init() {
		setProgress(content_sl);
		startProgress();

		int size = (int) (20 * Handler_System.getWidthRoate());
		Spanned spannable = Html.fromHtml(markup + markup);
		tv.setText(spannable);
		tv.setTextSize(size);
		tv.invalidate();
		tv.setOnLinkClickListener(new OnLinkClickListener() {
			@Override
			public void onLinkClick(String url) {
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse(url));
				startActivity(i);
			}
		});
	}
}