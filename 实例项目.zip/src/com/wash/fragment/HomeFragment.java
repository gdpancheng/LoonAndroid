package com.wash.fragment;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectAll;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.ioc.view.listener.OnItemClick;
import com.android.pc.util.Handler_Inject;
import com.android.pc.util.Handler_Ui;
import com.wash.activity.R;
import com.wash.adapter.HomeBannerPagerAdapter;
import com.wash.adapter.HomeListAdapter;
import com.wash.event.entity.FragmentEntity;
import com.wash.event.entity.SlidingEntity;
import com.wash.event.entity.SlidingToggleEntity;

/**
 * 主页
 * 
 * @author gdpancheng@gmail.com 2013-10-28 上午10:57:51
 */
public class HomeFragment extends BaseFragment {

	@InjectAll
	Views v;
	
	class Views{
		@InjectBinder(method = "onItemClick", listeners = { OnItemClick.class })
		private ListView home_list;
		private LinearLayout float_menu;
		@InjectBinder(method = "click", listeners = { OnClick.class })
		private View right_menu_bt;
		private HorizontalScrollView home_menu;
	}
	
	
	private View head;
	private FrameLayout banner_fl;
	private ImageView banner_back;

	private HomeListAdapter homeListAdapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View rootView = inflater.inflate(R.layout.activity_home, container, false);
		Handler_Inject.injectOrther(this, rootView);
		return rootView;
	}

	@InjectInit
	private void initView() {
		// ----------------------------------------------------------------------------------------
		// 界面初始化
		Handler_Ui.resetFL(v.home_list);
		head = inflater.inflate(R.layout.activity_home_banner, null);
		v.home_list.addHeaderView(head, null, true);
		homeListAdapter = new HomeListAdapter(activity, this, null);
		v.home_list.setAdapter(homeListAdapter);

		banner_fl = (FrameLayout) v.home_list.findViewById(R.id.banner_fl);
		banner_back = (ImageView) v.home_list.findViewById(R.id.banner_back);
		Handler_Ui.resetFLBack(banner_back);
		Handler_Ui.resetLLBack(banner_fl);

		ViewPager baner = (ViewPager) v.home_list.findViewById(R.id.baner);
		baner.setAdapter(new HomeBannerPagerAdapter(activity, null));
		baner.setCurrentItem(4000);
		baner.setOnTouchListener(on);

		Handler_Ui.resetFLBack(baner);
		Handler_Ui.resetFL(baner);

		v.home_menu.setOnTouchListener(on);
		setMenu(v.home_menu);

		v.home_list.setOnScrollListener(onScrollListener);
		// ----------------------------------------------------------------------------------------
		setProgress(v.home_list);
		startProgress();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

	}

	public void click(View v) {
		EventBus eventBus = EventBus.getDefault();
		SlidingToggleEntity slidingEntity = new SlidingToggleEntity();
		eventBus.post(slidingEntity);
	}

	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		EventBus eventBus = EventBus.getDefault();
		FragmentEntity fragmentEntity = new FragmentEntity();
		SlidingEntity slidingEntity = new SlidingEntity();

		if (arg2 == 4) {
			PaperInfoFragment paperInfoFragment = new PaperInfoFragment();
			fragmentEntity.setFragment(paperInfoFragment);
			eventBus.post(fragmentEntity);
			return;
		}

		QuestionInfoFragment fragment = new QuestionInfoFragment();
		Bundle args = new Bundle();
		args.putBoolean("isPhoto", false);
		args.putInt("type", 0);
		if (arg2 == 3) {
			args.putBoolean("isPhoto", true);
		}
		fragment.setArguments(args);
		fragmentEntity.setFragment(fragment);
		eventBus.post(fragmentEntity);
		eventBus.post(slidingEntity);
	}

	public void setMenu(HorizontalScrollView view) {

		LinearLayout layout = new LinearLayout(activity);
		FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
		layout.setPadding(10, 0, 10, 0);
		layout.setLayoutParams(layoutParams);
		layout.setGravity(Gravity.CENTER_VERTICAL);
		layoutParams.gravity = Gravity.CENTER_VERTICAL;

		layout.addView(insertImage(1));
		layout.addView(insertImage(1));
		layout.addView(insertImage(0));
		layout.addView(insertImage(1));
		layout.addView(insertImage(1));
		view.addView(layout);
	}

	private View insertImage(int i) {
		View view = inflater.inflate(R.layout.home_menu_item, null);
		if (i == 1) {
			return view;
		}
		view.setBackgroundResource(R.drawable.home_menu_select);
		return view;
	}

	OnScrollListener onScrollListener = new OnScrollListener() {

		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
		}

		@Override
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

			if (firstVisibleItem >= 1) {
				if (v.float_menu.getVisibility() != View.VISIBLE) {
					v.home_menu.scrollTo(homeListAdapter.getScollX(), 0);
					v.float_menu.setVisibility(View.VISIBLE);
				}
			} else {
				if (v.float_menu.getVisibility() != View.INVISIBLE) {
					homeListAdapter.getBusiness().scrollTo(v.home_menu.getScrollX(), 0);
					v.float_menu.setVisibility(View.INVISIBLE);
				}
			}
		}
	};

	@Override
	public void onResume() {
		super.onResume();
		EventBus eventBus = EventBus.getDefault();
		SlidingEntity slidingEntity = new SlidingEntity();
		slidingEntity.setSlidingEnable(true);
		slidingEntity.setResume(true);
		eventBus.post(slidingEntity);
	}
}