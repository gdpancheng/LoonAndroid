package com.wash.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.android.pc.ioc.inject.InjectAll;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.adapter.MessageAdapter;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class MessageFragment extends BaseFragment {
	
	@InjectAll
	Views v;
	
	class Views{
		@InjectBinder(method = "click", listeners = { OnClick.class })
		public TextView system_msg, question_msg, user_msg;
		public View right_line, left_line;
		public ListView message_list;
	} 

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View view = inflater.inflate(R.layout.activity_message, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}

	@InjectInit
	public void init() {
		v.message_list.setAdapter(new MessageAdapter(activity, null));
		setProgress(v.message_list);
		startProgress();
	}

	public void click(View view) {
		v.right_line.setVisibility(View.GONE);
		v.left_line.setVisibility(View.GONE);
		switch (view.getId()) {
		case R.id.system_msg:
			changeBackground(view);
			v.right_line.setVisibility(View.VISIBLE);
			break;
		case R.id.question_msg:
			changeBackground(view);
			break;
		case R.id.user_msg:
			v.left_line.setVisibility(View.VISIBLE);
			changeBackground(view);
			break;
		}
	}

	private void changeBackground(View view) {
		v.system_msg.setBackgroundResource(R.drawable.transparent);
		v.question_msg.setBackgroundResource(R.drawable.transparent);
		v.user_msg.setBackgroundResource(R.drawable.transparent);

		view.setBackgroundResource(R.drawable.question_button_back_press);
	};
}