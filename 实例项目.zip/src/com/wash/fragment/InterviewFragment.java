package com.wash.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectListener;
import com.android.pc.ioc.inject.InjectMethod;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.ioc.view.listener.OnItemClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.adapter.InterviewAdapter;
import com.wash.event.entity.FragmentEntity;
import com.wash.event.entity.SlidingEntity;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class InterviewFragment extends BaseFragment {

	@InjectView(binders = { @InjectBinder(method = "onItemClick", listeners = { OnItemClick.class }) })
	private ListView interview_list;
	@InjectView
	private ImageView line;
	@InjectView
	private FrameLayout contain;
	private InterviewAdapter adapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View rootView = inflater.inflate(R.layout.activity_interview, container, false);
		Handler_Inject.injectOrther(this, rootView);
		return rootView;
	}

	@InjectInit
	private void init(){
		adapter = new InterviewAdapter(activity, null);
		interview_list.setAdapter(adapter);
		setProgress(contain);
		startProgress();
	}

	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		InterviewInfoFragment fragment = new InterviewInfoFragment();
		EventBus eventBus = EventBus.getDefault();
		FragmentEntity fragmentEntity = new FragmentEntity();
		SlidingEntity slidingEntity = new SlidingEntity();

		fragmentEntity.setFragment(fragment);
		eventBus.post(fragmentEntity);
		eventBus.post(slidingEntity);
	}

	@InjectMethod(@InjectListener(ids = { R.id.lastest_interview, R.id.about_interview }, listeners = { OnClick.class }))
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.about_interview:
			line.setVisibility(View.GONE);
			adapter.setAbout(true);
			adapter.notifyDataSetChanged();
			break;
		default:
			line.setVisibility(View.VISIBLE);
			adapter.setAbout(false);
			adapter.notifyDataSetChanged();
			break;
		}
	}
}