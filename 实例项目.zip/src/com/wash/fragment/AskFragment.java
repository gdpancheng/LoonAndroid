package com.wash.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.event.entity.FragmentEntity;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class AskFragment extends BaseFragment {

	@InjectView
	private LinearLayout user_lay;
	@InjectView(binders = { @InjectBinder(method = "click", listeners = { OnClick.class }) })
	private TextView vip_title;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View view = inflater.inflate(R.layout.activity_ask_question, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}

	@InjectInit
	private void init() {
		user_lay.addView(insertImage());
		user_lay.addView(insertImage());
		user_lay.addView(insertImage());
		user_lay.addView(insertImage());
		user_lay.addView(insertImage());
		user_lay.addView(insertImage());
	}

	private View insertImage() {
		View view = inflater.inflate(R.layout.activity_question_user_item, null);
		return view;
	}

	public void click(View v) {
		switch (v.getId()) {
		case R.id.vip_title:
			EventBus eventBus = EventBus.getDefault();
			FragmentEntity fragmentEntity = new FragmentEntity();
			fragmentEntity.setFragment(new SelectUserFragment());
			eventBus.post(fragmentEntity);
			break;
		}
	}
}