package com.wash.fragment;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.android.pc.ioc.inject.InjectAll;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.util.Handler_Inject;
import com.android.pc.util.Handler_Ui;
import com.wash.activity.R;
import com.wash.view.ChangeLogDialog;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class AboutInfoFragment extends BaseFragment {

	
	@InjectAll
	Views vs;
	
	class Views{
		public View about_photo;
		public WebView about_me;
		public LinearLayout about_contain;
	}
	
	
	private View view;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		view = inflater.inflate(R.layout.activity_about, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}

	WebViewClient v = new WebViewClient() {
		@Override
		public void onPageFinished(WebView view, String url) {
			super.onPageFinished(view, url);
			mHandler.sendEmptyMessage(0);
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			super.onPageStarted(view, url, favicon);
		}
	};

	@InjectInit
	private void init(){
		Handler_Ui.resetLLBack(vs.about_photo);
		ChangeLogDialog _ChangeLog = new ChangeLogDialog(activity);
		vs.about_me.setBackgroundColor(Color.parseColor("#00000000"));
		vs.about_me.loadDataWithBaseURL(null, _ChangeLog.getHTML(), "text/html", "utf-8", null);
		vs.about_me.getSettings().setSupportMultipleWindows(true);
		vs.about_me.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
		vs.about_me.setWebViewClient(v);
		vs.about_me.setFocusable(false);
		vs.about_me.setClickable(false);
		
		setProgress(vs.about_contain);
		startProgress();
	}

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			checkHeight();
		}
	};

	/**
	 * 检测高度
	 * 
	 * @author gdpancheng@gmail.com 2013-10-28 上午11:03:19
	 * @return void
	 */
	private void checkHeight() {
		if (vs.about_me.getContentHeight() == 0) {
			mHandler.sendEmptyMessageDelayed(0, 10);
		} else {
			mHandler.post(new Runnable() {
				@SuppressWarnings("deprecation")
				@Override
				public void run() {
					vs.about_me.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) (vs.about_me.getContentHeight() * vs.about_me.getScale())));
				}
			});
		}
	}
}