package com.wash.fragment;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.pc.ioc.inject.InjectAll;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.android.pc.util.Handler_Ui;
import com.wash.activity.R;
import com.wash.adapter.OnlineAdapter;
import com.wash.adapter.OnlinePagerAdapter;
import com.wash.adapter.SelectedAdapter;
import com.wash.fragment.QuestionFragment.Views;
import com.wash.view.MyListView;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class SelectUserFragment extends BaseFragment {

	@InjectAll
	Views views;
	
	class Views{
		public MyListView user_list, select_user_list;
		public ViewPager newest;
		public View selected_lay;
		@InjectBinder(method = "click", listeners = { OnClick.class })
		public TextView add;

	}
	

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View rootView = inflater.inflate(R.layout.activity_select_user, container, false);
		Handler_Inject.injectOrther(this, rootView);
		return rootView;
	}

	@InjectInit
	private void init() {
		views.user_list.setAdapter(new OnlineAdapter(activity, null));
		views.select_user_list.setAdapter(new SelectedAdapter(activity, null));
		views.newest.setAdapter(new OnlinePagerAdapter(activity, null));
		views.newest.setCurrentItem(4);
		views.newest.setOnTouchListener(on);
		Handler_Ui.resetRLBack(views.newest);
		setProgress(views.user_list);
		startProgress();
	}

	public void click(View v) {
		switch (v.getId()) {
		case R.id.add:
			views.selected_lay.setVisibility(views.selected_lay.getVisibility()==View.GONE?View.VISIBLE:View.GONE);
			break;
		default:
			break;
		}
	}
}