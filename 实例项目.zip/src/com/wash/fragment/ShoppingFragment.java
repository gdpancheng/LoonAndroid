package com.wash.fragment;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.util.Handler_Inject;
import com.android.pc.util.Handler_Ui;
import com.wash.activity.R;
import com.wash.adapter.ShoppingAdapter;
import com.wash.adapter.ShoppingPagerAdapter;
import com.wash.view.MyListView;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class ShoppingFragment extends BaseFragment {

	@InjectView
	private MyListView shop_list;
	private View head;
	private ViewPager newest;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View rootView = inflater.inflate(R.layout.activity_shopping, container, false);
		Handler_Inject.injectOrther(this, rootView);
		return rootView;
	}
	
	@InjectInit
	private void init(){
		head = inflater.inflate(R.layout.activity_shopping_header, null);
		shop_list.addHeaderView(head, null, true);
		shop_list.setAdapter(new ShoppingAdapter(activity, null));

		newest = (ViewPager) shop_list.findViewById(R.id.newest);
		newest.setAdapter(new ShoppingPagerAdapter(activity, null));
		newest.setCurrentItem(4);
		newest.setOnTouchListener(on);

		Handler_Ui.resetRLBack(newest);
		
		setProgress(shop_list);
		startProgress();
	}
}