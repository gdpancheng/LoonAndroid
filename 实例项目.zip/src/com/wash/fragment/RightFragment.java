package com.wash.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.event.entity.FragmentEntity;
import com.wash.event.entity.SlidingToggleEntity;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class RightFragment extends BaseFragment {

	@InjectView(binders = { @InjectBinder(method = "click", listeners = { OnClick.class }) })
	View quesiton, paper, interview, message, more,order;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View view = inflater.inflate(R.layout.activity_right_menu, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}

	public void click(View v) {
		EventBus eventBus = EventBus.getDefault();
		FragmentEntity fragmentEntity = new FragmentEntity();
		Fragment fragment = null;
		switch (v.getId()) {
		case R.id.quesiton:
			fragment = new AskFragment();
			break;
		case R.id.paper:
			fragment = new UploadPaperFragment();
			break;
		case R.id.interview:
			fragment = new PublishInterviewFragment();
			break;
		case R.id.message:
			fragment = new MessageFragment();
			break;
		case R.id.order:
			fragment = new MyOrderFragment();
			break;
		case R.id.more:
			fragment = new MoreFragment();
			break;
		}
		fragmentEntity.setFragment(fragment);
		eventBus.post(fragmentEntity);
		SlidingToggleEntity slidingEntity = new SlidingToggleEntity();
		eventBus.post(slidingEntity);
	}
}