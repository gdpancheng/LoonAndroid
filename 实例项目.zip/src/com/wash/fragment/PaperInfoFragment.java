package com.wash.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.pc.ioc.inject.InjectView;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class PaperInfoFragment extends BaseFragment {

	@InjectView
	TextView store;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View view = inflater.inflate(R.layout.activity_paper_info, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}
}