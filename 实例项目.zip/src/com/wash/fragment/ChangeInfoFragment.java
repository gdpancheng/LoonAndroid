package com.wash.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.view.ChangeLogDialog;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class ChangeInfoFragment extends BaseFragment {

	@InjectView
	private WebView about_content;
	ChangeLogDialog _ChangeLog;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View view = inflater.inflate(R.layout.activity_custom_changelog, container, false);
		_ChangeLog = new ChangeLogDialog(activity);		
		Handler_Inject.injectOrther(this, view);
		return view;
	}
	
	@InjectInit
	private void init(){
		about_content.setBackgroundColor(Color.TRANSPARENT);
		about_content.loadDataWithBaseURL(null, _ChangeLog.getHTML(), "text/html", "utf-8", null);
		about_content.getSettings().setSupportMultipleWindows(true);
		about_content.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
		setProgress(about_content);
		startProgress();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}
}