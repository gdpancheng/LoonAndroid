package com.wash.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectListener;
import com.android.pc.ioc.inject.InjectMethod;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.event.entity.RegistEntity;

/**
 * 注册第一个页面
 * 
 * @author gdpancheng@gmail.com 2013-10-28 下午11:54:42
 */
public class FirstFragment extends BaseFragment {

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View view = inflater.inflate(R.layout.activity_regist_first, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}
	
	@InjectMethod(@InjectListener(ids = { R.id.next_bt }, listeners = { OnClick.class }))
	public void click(View v) {
		switch (v.getId()) {
		case R.id.next_bt:
			EventBus eventBus = EventBus.getDefault();
			RegistEntity fragmentEntity = new RegistEntity();
			fragmentEntity.setFragment(new SecondFragment());
			fragmentEntity.setIndex(2);
			eventBus.post(fragmentEntity);
			break;
		}
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public void onResume() {
		super.onResume();
		EventBus eventBus = EventBus.getDefault();
		RegistEntity fragmentEntity = new RegistEntity();
		fragmentEntity.setIndex(1);
		eventBus.post(fragmentEntity);
	}
}