package com.wash.fragment;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.util.Handler_Ui;
import com.wash.activity.R;
import com.wash.adapter.PaperAdapter;
import com.wash.adapter.RecommendPagerAdapter;
import com.wash.event.entity.FragmentEntity;
import com.wash.event.entity.SlidingEntity;
import com.wash.view.MyListView;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class PaperFragment extends BaseFragment {

	private MyListView question_list;
	private View head;
	private ViewPager recommend;
	private LinearLayout paper_menu;
	private View rootView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		rootView = inflater.inflate(R.layout.activity_paper, container, false);
		return rootView;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		question_list = (MyListView) rootView.findViewById(R.id.question_list);

		head = inflater.inflate(R.layout.activity_paper_header, null);
		question_list.addHeaderView(head, null, true);
		question_list.setAdapter(new PaperAdapter(activity, null));
		recommend = (ViewPager) question_list.findViewById(R.id.recommend);
		recommend.setAdapter(new RecommendPagerAdapter(activity, null));
		recommend.setCurrentItem(4);
		recommend.setOnTouchListener(on);
		paper_menu = (LinearLayout)rootView.findViewById(R.id.paper_menu);
		Handler_Ui.resetRLBack(recommend);
		question_list.setOnScrollListener(onScrollListener);
		question_list.setOnItemClickListener(l);
		setProgress(question_list);
		startProgress();
	}
	
	OnItemClickListener l = new OnItemClickListener() {
		@Override
        public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			PaperInfoFragment fragment = new PaperInfoFragment();
			
			EventBus eventBus = EventBus.getDefault();
			FragmentEntity fragmentEntity = new FragmentEntity();
			SlidingEntity slidingEntity = new SlidingEntity();
			
			fragmentEntity.setFragment(fragment);
			eventBus.post(fragmentEntity);
			eventBus.post(slidingEntity);
        }
	};
	
	OnScrollListener onScrollListener = new OnScrollListener() {
		
		@Override
		public void onScrollStateChanged(AbsListView view, int scrollState) {
			
		}
		
		@Override
		public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
			if (firstVisibleItem >= 1) {
				paper_menu.setVisibility(View.VISIBLE);
            }else {
            	paper_menu.setVisibility(View.INVISIBLE);
			}
		}
	};
}