package com.wash.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.adapter.MyAnswerQuestionAdapter;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class MyQuestionAnswerFragment extends BaseFragment {

	@InjectView(binders = { @InjectBinder(method = "click", listeners = { OnClick.class }) })
	private TextView left, right, center;
	@InjectView
	private ListView my_question_list;
	private MyAnswerQuestionAdapter adapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View view = inflater.inflate(R.layout.activity_my_answer_questions, container, false);
		Handler_Inject.injectOrther(this, view);
		return view;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		left.setText(R.string.my_questions_ask_sucess);
		center.setText(R.string.my_questions_ask_error);
		right.setText(R.string.my_questions_ask_no);

		adapter = new MyAnswerQuestionAdapter(activity, null);
		my_question_list.setAdapter(adapter);

		setProgress(my_question_list);
		startProgress();
	}

	public void click(View v) {
		switch (v.getId()) {
		case R.id.left:
			adapter.setStatus(1);
			adapter.notifyDataSetChanged();
			break;
		case R.id.center:
			adapter.setStatus(2);
			adapter.notifyDataSetChanged();
			break;
		default:
			adapter.setStatus(3);
			adapter.notifyDataSetChanged();
			break;
		}
	}
}