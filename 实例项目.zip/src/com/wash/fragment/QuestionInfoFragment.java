package com.wash.fragment;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.pc.ioc.inject.InjectAll;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.fragment.QuestionFragment.Views;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-8-4
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class QuestionInfoFragment extends BaseFragment {

	private boolean isPhoto;
	private int type;

	@InjectAll
	Views views;
	
	class Views{
		public ImageView question_image;
		public TextView question_content;
		public View main_contain;
	}
	
	
	View view;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		isPhoto = getArguments().getBoolean("isPhoto");
		type = getArguments().getInt("type");
		if (type == 0) {
			view = inflater.inflate(R.layout.activity_question_info_one, container, false);
		} else if (type == 1) {
			view = inflater.inflate(R.layout.activity_question_info_two, container, false);
		} else {
			view = inflater.inflate(R.layout.activity_question_info_three, container, false);
		}
		Handler_Inject.injectOrther(this, view);
		return view;
	}

	@InjectInit
	private void init(){
		if (isPhoto) {
			views.question_content.setVisibility(View.GONE);
			views.question_image.setVisibility(View.VISIBLE);
		}
	}
}