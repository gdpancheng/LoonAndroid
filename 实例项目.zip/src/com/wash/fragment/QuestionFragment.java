package com.wash.fragment;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.pc.ioc.inject.InjectAll;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Inject;
import com.wash.activity.R;
import com.wash.adapter.QuestionPagerAdapter;

public class QuestionFragment extends BaseFragment {
	
	@InjectAll
	Views views;
	
	class Views{
		@InjectBinder(method = "click", listeners = { OnClick.class })
		public TextView newest, hot, related;
		public ViewPager question_page;
		public TextView question_finish, question_all, question_no_finish;
	}
	
	private TextView[] texts= new  TextView[3];
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		this.inflater = inflater;
		View rootView = inflater.inflate(R.layout.activity_question, container, false);
		Handler_Inject.injectOrther(this, rootView);
		return rootView;
	}

	@InjectInit
	public void init() {
		
		texts[0] = views.question_finish;
		texts[1] = views.question_all;
		texts[2] = views.question_no_finish;
		
		views.question_page.setAdapter(new QuestionPagerAdapter(activity, null));
		views.question_page.setOnPageChangeListener(changeListener);
		views.question_page.setCurrentItem(1);

		setProgress(views.question_page);
		startProgress();
	}

	OnPageChangeListener changeListener = new OnPageChangeListener() {
		@Override
		public void onPageSelected(int arg0) {
			System.out.println(arg0);
			changeTextColor(texts[arg0]);
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
		}

		@Override
		public void onPageScrollStateChanged(int arg0) {
		}
	};

	public void click(View v) {
		switch (v.getId()) {
		case R.id.newest:
			changeBackground(v);
			break;
		case R.id.hot:
			changeBackground(v);
			break;
		case R.id.related:
			changeBackground(v);
			break;
		}
	}

	private void changeBackground(View v) {
		views.newest.setBackgroundResource(R.drawable.transparent);
		views.hot.setBackgroundResource(R.drawable.transparent);
		views.related.setBackgroundResource(R.drawable.transparent);
		
		v.setBackgroundResource(R.drawable.question_button_back_press);
	};
	
	private void changeTextColor(TextView v) {
		
		views.question_finish.setTextColor(getResources().getColor(R.color.paper_menu_text));
		views.question_all.setTextColor(getResources().getColor(R.color.paper_menu_text));
		views.question_no_finish.setTextColor(getResources().getColor(R.color.paper_menu_text));
		
		v.setTextColor(getResources().getColor(R.color.personal_yellow));
	};
}