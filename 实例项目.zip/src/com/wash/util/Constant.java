package com.wash.util;
/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-10-5
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class Constant {
	
	public static final int MY_STORAGE_TYPE_QUESTION = 0;
	public static final int MY_STORAGE_TYPE_PAPER = 1;
	
	public static final int HTTP_OK = 1;
	public static final int HTTP_ERR = 1;
	
	public static final String FRAGEMENT_DATA = "fragement_data";
	
	 public static final class URL{
		 public static final String common_url = "http://panchengoyo.cf/knowledge";
		 //----------------------------------------------------------------------------------------
		 //user相关操作
		 public static final String common_user_url = common_url+"/user/";
		 public static final String user_login = common_user_url+"login";
		 public static final String user_regist = common_user_url+"regist";
	 }
}
