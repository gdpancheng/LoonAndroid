package com.wash.activity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentManager.BackStackEntry;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectLayer;
import com.android.pc.ioc.inject.InjectView;
import com.wash.event.entity.RegistEntity;
import com.wash.fragment.FirstFragment;

@InjectLayer(R.layout.activity_regist)
public class RegistActivity extends FragmentActivity {

	@InjectView
	TextView first, second, three;

	@InjectInit
	private void init() {
		// ----------------------------------------------------------------------
		// 通知事件
		EventBus eventBus = EventBus.getDefault();
		eventBus.register(this);
		// ----------------------------------------------------------------------
		startFragmentAdd(new FirstFragment());
	}

	/**
	 * 切换面板
	 * 
	 * @author gdpancheng@gmail.com 2013-10-26 下午2:43:06
	 * @param fragment
	 * @return void
	 */
	public void startFragmentAdd(Fragment fragment) {
		FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		Fragment to_fragment = fragmentManager.findFragmentByTag(fragment.getClass().getName());
		if (to_fragment != null) {
			for (int i = 0; i < fragmentManager.getBackStackEntryCount(); i++) {
				BackStackEntry entry = fragmentManager.getBackStackEntryAt(i);
				if (fragment.getClass().getName().equals(entry.getName())) {
					fragmentManager.popBackStack(entry.getName(), 1);
				}
			}
		}
		fragmentTransaction.addToBackStack(fragment.getClass().getName());
		fragmentTransaction.replace(R.id.content_frame, fragment, fragment.getClass().getName()).commitAllowingStateLoss();
	}

	/**
	 * 刷新图标
	 * @author gdpancheng@gmail.com 2013-10-31 上午12:02:19
	 * @param v
	 * @return void
	 */
	private void referView(View v) {
		first.setBackgroundResource(R.drawable.regist_normal_bt);
		second.setBackgroundResource(R.drawable.regist_normal_bt);
		three.setBackgroundResource(R.drawable.regist_normal_bt);

		v.setBackgroundResource(R.drawable.regist_press_bt);
	}

	/**
	 * 退到注册第一页了 再后退 就关闭当前activity
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // 按下的如果是BACK，同时没有重复
			Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
			if (fragment.getClass().getName().equals(FirstFragment.class.getName())) {
				finish();
				return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	
	/**
	 * 监听fragment的更改 切换
	 * @author gdpancheng@gmail.com 2013-10-31 上午12:01:11
	 * @param event
	 * @return void
	 */
	public void onEventMainThread(RegistEntity event) {
		switch (event.getIndex()) {
		case 1:
			referView(first);
			break;
		case 2:
			referView(second);
			break;
		case 3:
			referView(three);
			break;
		}
		Fragment fragment = event.getFragment();
		if (fragment == null) {
	        return;
        }
		startFragmentAdd(fragment);
	}
	
	@Override
	protected void onDestroy() {
	    super.onDestroy();
		EventBus eventBus = EventBus.getDefault();
		eventBus.unregister(this);
	}
}
