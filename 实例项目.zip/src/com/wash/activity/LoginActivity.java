package com.wash.activity;

import java.util.LinkedHashMap;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectHttpErr;
import com.android.pc.ioc.inject.InjectHttpOk;
import com.android.pc.ioc.inject.InjectLayer;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.internet.FastHttpHander;
import com.android.pc.ioc.internet.ResponseEntity;
import com.android.pc.ioc.verification.Rule;
import com.android.pc.ioc.verification.Validator.ValidationListener;
import com.android.pc.ioc.verification.annotation.Regex;
import com.android.pc.ioc.verification.annotation.TextRule;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Json;
import com.wash.entity.Login;
import com.wash.util.Constant;

@InjectLayer(R.layout.activity_login)
public class LoginActivity extends Activity implements ValidationListener {

	@InjectView(binders = { @InjectBinder(method = "click", listeners = { OnClick.class }) })
	ImageButton button_login, info;
	@Regex(message = "6到15位字母数字下划线", trim = true, pattern = "[a-zA-Z0-9_]{6,15}", order = 1)
	@InjectView
	EditText user_name;
	@TextRule(maxLength = 16, minLength = 4, trim = true, message = "密码长度4到16位", order = 2)
	@InjectView
	EditText user_password;
	@InjectView(binders = { @InjectBinder(method = "click", listeners = { OnClick.class }) })
	TextView regist, forgot;

	public void click(View v) {
		switch (v.getId()) {
		case R.id.button_login:
			// 验证
//			Validator validator = new Validator(this);
//			validator.setValidationListener(this);
//			validator.validate();
			startActivity(new Intent(LoginActivity.this, MainActivity.class));
			finish();
			break;
		case R.id.info:
			startActivity(new Intent(LoginActivity.this, InformationActivity.class));
			break;
		case R.id.regist:
			startActivity(new Intent(LoginActivity.this, RegistActivity.class));
			break;
		case R.id.forgot:
			startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class));
			break;
		}
	}

	/**
	 * 自动验证成功的方法
	 */
	@Override
	public void onValidationSucceeded() {
		LinkedHashMap<String, String> params = new LinkedHashMap<String, String>();
		params.put("user_name", user_name.getText().toString().trim());
		params.put("password", user_password.getText().toString().trim());
		FastHttpHander.ajax(Constant.URL.user_login, params, this);
	}

	@InjectHttpOk
	private void success(ResponseEntity entity) {
		Login login = Handler_Json.JsonToBean(Login.class, entity.getContentAsString());
		System.out.println(entity);
		if (login.getStatus() == Constant.HTTP_OK) {
			startActivity(new Intent(LoginActivity.this, MainActivity.class));
			finish();
		} else {
		}
	}

	@InjectHttpErr
	private void fail(ResponseEntity entity) {
	}

	/**
	 * 自动验证失败的方法
	 */
	@Override
	public void onValidationFailed(View failedView, Rule<?> failedRule) {
		String message = failedRule.getFailureMessage();
		if (failedView instanceof EditText) {
			failedView.requestFocus();
			((EditText) failedView).setError(message);
		} else {
			Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
		}
	};
}
