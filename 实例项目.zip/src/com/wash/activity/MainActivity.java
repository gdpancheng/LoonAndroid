package com.wash.activity;

import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentManager.BackStackEntry;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectAll;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectLayer;
import com.android.pc.ioc.view.listener.OnClick;
import com.android.pc.util.Handler_Ui;
import com.slidingmenu.lib.SlidingMenu;
import com.wash.event.entity.FragmentEntity;
import com.wash.event.entity.SlidingEntity;
import com.wash.event.entity.SlidingToggleEntity;
import com.wash.fragment.AskFragment;
import com.wash.fragment.HomeFragment;
import com.wash.fragment.InterviewFragment;
import com.wash.fragment.MoreFragment;
import com.wash.fragment.MyCommentFragment;
import com.wash.fragment.MyInterviewFragment;
import com.wash.fragment.MyPaperFragment;
import com.wash.fragment.MyQuestionAnswerFragment;
import com.wash.fragment.MyQuestionAskFragment;
import com.wash.fragment.MyStorageFragment;
import com.wash.fragment.PaperFragment;
import com.wash.fragment.PublishInterviewFragment;
import com.wash.fragment.QuestionFragment;
import com.wash.fragment.RightFragment;
import com.wash.fragment.SearchFragment;
import com.wash.fragment.ShoppingFragment;
import com.wash.fragment.UploadPaperFragment;
import com.wash.util.Constant;
import com.wash.view.DrawerLayout;
import com.wash.view.DrawerLayout.DrawerListener;

@InjectLayer(R.layout.activity_main)
public class MainActivity extends FragmentActivity {

	@InjectAll
	Views v;

	class Views {
		public DrawerLayout drawer_layout;
		public View right, center, personal_center, personal_back;
		@InjectBinder(method = "click", listeners = { OnClick.class })
		public View content_frame, search, person_menu_ask, person_menu_paper, person_menu_interview, person_menu_more, bottom_question, bottom_center, bottom_paper, bottom_shopping, bottom_interview;
		@InjectBinder(method = "click", listeners = { OnClick.class })
		public RelativeLayout presonal_center_ask, presonal_center_answer, presonal_center_sell, presonal_center_buy, presonal_center_store_question, presonal_center_store_paper, presonal_center_interview, presonal_center_comment;
		public FrameLayout bottom_first;
	}

	private int height = 0;
	public SlidingMenu menu;
	// ---------------------------------------------------------------------------------------------------
	// 标记右菜单的状态
	private boolean isSliding = false;

	@InjectInit
	private void init() {
		// ----------------------------------------------------------------------
		// 通知事件
		EventBus eventBus = EventBus.getDefault();
		eventBus.register(this);
		// ----------------------------------------------------------------------
		// 右侧滑
		menu = new SlidingMenu(this);
		menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		menu.setShadowWidthRes(R.dimen.shadow_width);
		menu.setBehindOffsetRes(R.dimen.slidingmenu_offset);
		menu.setFadeDegree(0.35f);
		menu.setMode(SlidingMenu.RIGHT);
		getSupportFragmentManager().beginTransaction().replace(R.id.menu_frame, new RightFragment()).commit();
		menu.setSecondaryMenu(R.layout.menu_frame);
		menu.setSecondaryShadowDrawable(R.drawable.shadowright);
		menu.attachToActivity(this, SlidingMenu.SLIDING_CONTENT);
		// ----------------------------------------------------------------------
		// 适配
		v.drawer_layout.setDrawerListener(listener);
		Handler_Ui.resetRLBack(v.personal_back);
		Handler_Ui.resetRL(v.right);
		startFragmentAdd(new HomeFragment());
		// ----------------------------------------------------------------------
		// 重新绘制底部菜单的高度
		v.bottom_first.post(new Runnable() {
			@Override
			public void run() {
				Rect viewRect = new Rect();
				v.bottom_first.getGlobalVisibleRect(viewRect);
				height = viewRect.bottom - viewRect.top;
				handler.sendEmptyMessage(0);
			}
		});
		// ------------------------------------------------------------------------
	}

	/**
	 * Fragment 跳转事件
	 * 
	 * @author gdpancheng@gmail.com 2013-10-28 上午10:54:48
	 * @param fragment
	 * @return void
	 */
	private void startFragmentAdd(Fragment fragment) {
		if (fragment.getClass() == HomeFragment.class) {
			menu.setSlidingEnabled(true);
			isSliding = true;
		} else {
			isSliding = false;
			menu.setSlidingEnabled(false);
		}
		// ------------------------------------------------------------------------
		FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		Fragment to_fragment = fragmentManager.findFragmentByTag(fragment.getClass().getName());
		if (to_fragment != null) {
			for (int i = 0; i < fragmentManager.getBackStackEntryCount(); i++) {
				BackStackEntry entry = fragmentManager.getBackStackEntryAt(i);
				if (fragment.getClass().getName().equals(entry.getName())) {
					fragmentManager.popBackStack(entry.getName(), 1);
				}
			}
		}
		fragmentTransaction.addToBackStack(fragment.getClass().getName());
		fragmentTransaction.replace(R.id.content_frame, fragment, fragment.getClass().getName()).commitAllowingStateLoss();
		// ------------------------------------------------------------------------
		// 关闭遮罩层 当中间的视图切换组件的时候 遮罩层自动关闭
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				v.drawer_layout.closeDrawer(v.personal_center);
			}
		}, 100);
	}

	/**
	 * 监听后退事件
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) { // 按下的如果是BACK，同时没有重复
			Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
			if (fragment.getClass().getName().equals(HomeFragment.class.getName())) {
				finish();
				return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}

	public void click(View v) {
		switch (v.getId()) {
		case R.id.bottom_question:
			startFragmentAdd(new QuestionFragment());
			break;
		case R.id.bottom_center:
			startFragmentAdd(new HomeFragment());
			break;
		case R.id.bottom_paper:
			startFragmentAdd(new PaperFragment());
			break;
		case R.id.bottom_shopping:
			startFragmentAdd(new ShoppingFragment());
			break;
		case R.id.bottom_interview:
			startFragmentAdd(new InterviewFragment());
			break;
		case R.id.person_menu_ask:
			startFragmentAdd(new AskFragment());
			break;
		case R.id.person_menu_paper:
			startFragmentAdd(new UploadPaperFragment());
			break;
		case R.id.person_menu_interview:
			startFragmentAdd(new PublishInterviewFragment());
			break;
		case R.id.person_menu_more:
			startFragmentAdd(new MoreFragment());
			break;
		case R.id.search:
			startFragmentAdd(new SearchFragment());
			break;
		case R.id.presonal_center_ask:
			startFragmentAdd(new MyQuestionAskFragment());
			break;
		case R.id.presonal_center_answer:
			startFragmentAdd(new MyQuestionAnswerFragment());
			break;
		case R.id.presonal_center_sell:
			startFragmentAdd(new MyPaperFragment());
			break;
		case R.id.presonal_center_buy:
			startFragmentAdd(new MyPaperFragment());
			break;
		case R.id.presonal_center_store_question:
			MyStorageFragment myStorageFragment = new MyStorageFragment();
			Bundle args = new Bundle();
			args.putInt(Constant.FRAGEMENT_DATA, Constant.MY_STORAGE_TYPE_QUESTION);
			myStorageFragment.setArguments(args);
			startFragmentAdd(myStorageFragment);
			break;
		case R.id.presonal_center_store_paper:
			MyStorageFragment myStorageFragment2 = new MyStorageFragment();
			Bundle args2 = new Bundle();
			args2.putInt(Constant.FRAGEMENT_DATA, Constant.MY_STORAGE_TYPE_PAPER);
			myStorageFragment2.setArguments(args2);
			startFragmentAdd(myStorageFragment2);
			break;
		case R.id.presonal_center_interview:
			startFragmentAdd(new MyInterviewFragment());
			break;
		case R.id.presonal_center_comment:
			startFragmentAdd(new MyCommentFragment());
			break;
		}
	}

	/**
	 * 监听触摸事件 当手指抬起来的时候 还原遮罩层和右菜单的状态
	 */
	public boolean dispatchTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {
		case MotionEvent.ACTION_UP:
			// 抬起手指的时候 恢复之前的状态
			menu.setSlidingEnabled(isSliding);
			v.drawer_layout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
			break;
		}
		return super.dispatchTouchEvent(ev);
	};

	DrawerListener listener = new DrawerListener() {
		@Override
		public void onDrawerStateChanged(int arg0) {
		}

		@Override
		public void onDrawerSlide(View arg0, float arg1) {
			RelativeLayout.LayoutParams l = (LayoutParams) v.right.getLayoutParams();
			int w = l.width;
			if (w == -1) {
				w = v.right.getWidth();
			}
			l.rightMargin = (int) (w * (arg1 - 1));
			v.right.setLayoutParams(l);
			if (arg1 == 1) {
				v.center.setVisibility(View.VISIBLE);
				return;
			}
			if (v.center.getVisibility() == View.VISIBLE) {
				v.center.setVisibility(View.GONE);
				// center.setAnimation();
			}
		}

		@Override
		public void onDrawerOpened(View arg0) {
			menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
			v.center.setVisibility(View.VISIBLE);
		}

		@Override
		public void onDrawerClosed(View arg0) {
			menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
		}
	};

	/**
	 * 重新计算底部菜单高度
	 */
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) v.content_frame.getLayoutParams();
			layoutParams.bottomMargin = height;
			v.content_frame.setLayoutParams(layoutParams);
		};
	};

	/**
	 * 监听Fragment跳转
	 * 
	 * @author gdpancheng@gmail.com 2013-10-28 上午10:52:19
	 * @param event
	 * @return void
	 */
	public void onEventMainThread(FragmentEntity event) {
		startFragmentAdd(event.getFragment());
	}

	/**
	 * 监听侧导航的状态是否是禁止
	 * 
	 * @author gdpancheng@gmail.com 2013-10-28 上午10:52:35
	 * @param event
	 * @return void
	 */
	public void onEventMainThread(SlidingEntity event) {
		if (event.isResume()) {
			// 在按了后退以后 如果页面有右侧菜单 则会走这里哦
			this.isSliding = event.isSlidingEnable();
		}
		if (event.isViewPage()) {
			menu.setSlidingEnabled(isSliding);
		} else {
			menu.setSlidingEnabled(event.isSlidingEnable());
		}

		if (event.isSlidingEnable()) {
			v.drawer_layout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
		} else {
			v.drawer_layout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
		}
	}

	/**
	 * 监听顶部右导航的点击事件
	 * 
	 * @author gdpancheng@gmail.com 2013-10-28 上午10:53:05
	 * @param event
	 * @return void
	 */
	public void onEventMainThread(SlidingToggleEntity event) {
		if (menu.isMenuShowing()) {
			menu.toggle();
		} else {
			menu.showMenu();
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		EventBus eventBus = EventBus.getDefault();
		eventBus.unregister(this);
	}
}
