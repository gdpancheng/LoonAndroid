package com.wash.activity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.android.pc.ioc.event.EventBus;
import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectLayer;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.wash.fragment.ForgotEmailFragment;
import com.wash.fragment.ForgotPhoneFragment;

@InjectLayer(R.layout.activity_forgot)
public class ForgotPasswordActivity extends FragmentActivity {

	
	@InjectView(binders = { @InjectBinder(method = "click", listeners = { OnClick.class }) })
	View mobile_rl, email_rl;

	@InjectInit
	private void init() {
		startFragmentAdd(new ForgotPhoneFragment());
	}

	/**
	 * 切换面板
	 * 
	 * @author gdpancheng@gmail.com 2013-10-26 下午2:43:06
	 * @param fragment
	 * @return void
	 */
	public void startFragmentAdd(Fragment fragment) {
		FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(R.id.content_frame, fragment, fragment.getClass().getName()).commit();
	}

	public void click(View v) {
		referView(v);
		switch (v.getId()) {
		case R.id.mobile_rl:
			startFragmentAdd(new ForgotPhoneFragment());
			break;
		case R.id.email_rl:
			startFragmentAdd(new ForgotEmailFragment());
			break;
		}
	}

	private void referView(View v) {
		mobile_rl.setBackgroundResource(R.drawable.normal_arrows);
		email_rl.setBackgroundResource(R.drawable.normal_arrows);

		v.setBackgroundResource(R.drawable.select_arrows);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		EventBus eventBus = EventBus.getDefault();
		eventBus.unregister(this);
	}
}
