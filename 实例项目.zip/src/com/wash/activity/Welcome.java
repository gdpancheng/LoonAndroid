package com.wash.activity;

import android.app.Activity;
import android.view.View;

import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectLayer;
import com.android.pc.ioc.inject.InjectView;

@InjectLayer(R.layout.fragment_progress)
public class Welcome extends Activity {

	@InjectView
	View progress_container;

	@InjectInit
	private void initView() {
		progress_container.setVisibility(View.VISIBLE);
	}
}
