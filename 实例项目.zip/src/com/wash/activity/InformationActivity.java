package com.wash.activity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.TextView;

import com.android.pc.ioc.inject.InjectBinder;
import com.android.pc.ioc.inject.InjectInit;
import com.android.pc.ioc.inject.InjectLayer;
import com.android.pc.ioc.inject.InjectView;
import com.android.pc.ioc.view.listener.OnClick;
import com.wash.fragment.AboutInfoFragment;
import com.wash.fragment.ChangeInfoFragment;
import com.wash.fragment.HelpFragment;

@InjectLayer(R.layout.activity_info)
public class InformationActivity extends FragmentActivity {

	@InjectView(binders = { @InjectBinder(method = "click", listeners = { OnClick.class }) })
	TextView help, about, treaty;

	@InjectInit
	private void init() {
		startFragmentAdd(new AboutInfoFragment());
	}

	/**
	 * 切换面板 
	 * @author gdpancheng@gmail.com 2013-10-26 下午2:43:06
	 * @param fragment
	 * @return void
	 */
	public void startFragmentAdd(Fragment fragment) {
		FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
		fragmentTransaction.replace(R.id.content_frame, fragment, fragment.getClass().getName()).commit();
	}

	public void click(View v) {
		referView(v);
		switch (v.getId()) {
		case R.id.help:
			startFragmentAdd(new HelpFragment());
			break;
		case R.id.about:
			startFragmentAdd(new AboutInfoFragment());
			break;

		case R.id.treaty:
			startFragmentAdd(new ChangeInfoFragment());
			break;
		}
	}

	@SuppressWarnings("deprecation")
    private void referView(View v) {
		help.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		about.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		treaty.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		v.setBackgroundResource(R.drawable.question_button_back_press);
	}
}
