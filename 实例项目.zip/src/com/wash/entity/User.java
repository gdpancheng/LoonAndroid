package com.wash.entity;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2014-1-28
 * Copyright @ 2014 BU
 * Description: 类描述
 *
 * History:
 */
public class User {
	
	private String user_name;
	private String password;

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
    public String toString() {
	    return "User [user_name=" + user_name + ", password=" + password + "]";
    }

}
