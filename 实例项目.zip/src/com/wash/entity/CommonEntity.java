package com.wash.entity;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2014-1-28
 * Copyright @ 2014 BU
 * Description: 类描述
 *
 * History:
 */
public class CommonEntity {

	private int status;
	private String msg;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	@Override
    public String toString() {
	    return "CommonEntity [status=" + status + ", msg=" + msg + "]";
    }
}
