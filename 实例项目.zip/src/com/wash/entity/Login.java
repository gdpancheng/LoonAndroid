package com.wash.entity;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2014-1-28
 * Copyright @ 2014 BU
 * Description: 类描述
 *
 * History:
 */
public class Login extends CommonEntity {

	private User data;

	public User getData() {
		return data;
	}

	public void setData(User data) {
		this.data = data;
	}
	
	@Override
    public String toString() {
	    return "Login [data=" + data + ", toString()=" + super.toString() + "]";
    }
}
