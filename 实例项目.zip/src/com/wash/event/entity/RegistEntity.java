package com.wash.event.entity;

import android.support.v4.app.Fragment;

/**
 * Fragment 跳转对象
 * 
 * @author gdpancheng@gmail.com 2013-10-28 上午10:06:08
 */
public class RegistEntity {

	private Fragment fragment;
	private int index;

	public Fragment getFragment() {
		return fragment;
	}

	public void setFragment(Fragment fragment) {
		this.fragment = fragment;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

}
