package com.wash.event.entity;

/**
 * 右部展开控制对象
 * @author gdpancheng@gmail.com 2013-10-28 上午10:05:43
 */
public class SlidingToggleEntity {
	
	private boolean isSlidingEnable = false;

	public boolean isSlidingEnable() {
		return isSlidingEnable;
	}

	public void setSlidingEnable(boolean isSlidingEnable) {
		this.isSlidingEnable = isSlidingEnable;
	}

}
