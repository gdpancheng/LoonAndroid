package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wash.activity.R;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-5-8
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class MyAskQuestionAdapter extends CommonAdapter {

	private LayoutInflater inflater;
	private int status = 0;

	public MyAskQuestionAdapter(Activity context, ArrayList<HashMap<String, Object>> data) {
		inflater = LayoutInflater.from(context);
		this.activity = context;
		this.data = data;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public View view(int position, View convertView, ViewGroup parent) {
		convertView = inflater.inflate(R.layout.activity_my_question_ask_item, null);
		TextView label = (TextView) convertView.findViewById(R.id.label);
		if (position % 3 == 0) {
			label.setVisibility(View.VISIBLE);
		}
		if (position % 3 == 1) {
			label.setText("完结");
			label.setTextColor(activity.getResources().getColor(R.color.personal_text_color));
		}

		if (position % 3 == 2) {
			label.setText("紧急");
			label.setTextColor(Color.RED);
		}

		if (status == 1) {
			label.setTextColor(activity.getResources().getColor(R.color.personal_text_color));
			label.setText("完结");
		}

		if (status == 2) {
			label.setTextColor(activity.getResources().getColor(R.color.personal_yellow));
			label.setText("进行中");
			if (position % 3 == 2) {
				label.setText("紧急");
				label.setTextColor(Color.RED);
			}
		}
		return convertView;
	}

}