package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.TextView;

import com.wash.activity.R;
import com.wash.fragment.HomeFragment;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-5-8
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class HomeListAdapter extends CommonAdapter {

	private LayoutInflater inflater;
	private HomeFragment homeFragment;
	private HorizontalScrollView business;

	public HomeListAdapter(Activity activity, HomeFragment homeFragment, ArrayList<HashMap<String, Object>> data) {
		this.inflater = LayoutInflater.from(activity);
		this.activity = activity;
		this.data = data;
		this.homeFragment = homeFragment;
	}

	public int getScollX() {
		if (business != null) {
			return business.getScrollX();
		}
		return 0;
	}

	public HorizontalScrollView getBusiness() {
		return business;
	}

	@Override
	public View view(int position, View convertView, ViewGroup parent) {
		if (position == 0) {
			convertView = inflater.inflate(R.layout.activity_home_menu, null);
			business = (HorizontalScrollView) convertView.findViewById(R.id.scrollview);
			homeFragment.setMenu(business);
			business.setOnTouchListener(homeFragment.on);
			return convertView;
		}
		
		if (position == 3) {
			convertView = inflater.inflate(R.layout.activity_paper_item, null);
			return convertView;
		}

		convertView = inflater.inflate(R.layout.activity_home_item, null);
		TextView question_content = (TextView) convertView.findViewById(R.id.question_content);
		ImageView question_image = (ImageView) convertView.findViewById(R.id.question_image);
		ImageView label = (ImageView) convertView.findViewById(R.id.label);
		if (position == 1) {
			label.setVisibility(View.VISIBLE);
		}
		question_content.setVisibility(View.VISIBLE);
		if (position == 2) {
			question_content.setVisibility(View.GONE);
			question_image.setVisibility(View.VISIBLE);
		}
		return convertView;
	}
	
	
	class Holder{
		
	}
	
	class Holder_Paper extends Holder{
		TextView company_name;
	}

	class Holder_Question extends Holder{
		TextView question_title;
	}
}