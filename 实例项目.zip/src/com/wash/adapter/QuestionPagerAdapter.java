package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import com.android.pc.ioc.event.EventBus;
import com.wash.activity.R;
import com.wash.event.entity.FragmentEntity;
import com.wash.event.entity.SlidingEntity;
import com.wash.fragment.QuestionInfoFragment;
import com.wash.view.MyListView;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-7-16
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class QuestionPagerAdapter extends CommonPagerAdapter {

	private CommonAdapter[] adapters;

	public QuestionPagerAdapter(Context context, ArrayList<HashMap<String, Object>> data) {
		this.context = context;
		this.data = data;
		inflater = LayoutInflater.from(context);
		adapters = new CommonAdapter[3];
	}

	@Override
	public int getCount() {
		return 3;
	}

	@Override
	public void setPrimaryItem(View container, int position, Object object) {
		for (int i = 0; i < adapters.length; i++) {
			CommonAdapter adapter = adapters[i];
			if (adapter == null) {
				continue;
			}
			if (i == position) {
				adapter.setCount(20);
			} else {
				adapter.setCount(0);
			}
			adapter.notifyDataSetChanged();
		}
	}

	@Override
	public Object instantiateItem(ViewGroup view, int position) {
		adapters[position] = new QuestionAdapter(context, null);
		View views = inflater.inflate(R.layout.activity_question_page, null);
		MyListView question_list = (MyListView) views.findViewById(R.id.question_list);
		question_list.setAdapter(adapters[position]);
		question_list.setOnItemClickListener(l);
		pageMap.put(position, views);
		view.addView(views);
		return views;
	}

	OnItemClickListener l = new OnItemClickListener() {
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
			QuestionInfoFragment fragment = new QuestionInfoFragment();
			Bundle args = new Bundle();
			args.putBoolean("isPhoto", false);
			args.putInt("type", 0);
			if (arg2 % 3 == 1) {
				args.putInt("type", 1);
			}
			if (arg2 % 3 == 2) {
				args.putInt("type", 2);
			}
			if (arg2 == 1) {
				args.putBoolean("isPhoto", true);
			}
			fragment.setArguments(args);

			EventBus eventBus = EventBus.getDefault();
			FragmentEntity fragmentEntity = new FragmentEntity();
			SlidingEntity slidingEntity = new SlidingEntity();

			fragmentEntity.setFragment(fragment);
			eventBus.post(fragmentEntity);
			eventBus.post(slidingEntity);

		}
	};
}