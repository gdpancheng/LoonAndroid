package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wash.activity.R;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-7-16
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class RecommendPagerAdapter extends CommonPagerAdapter {

	public RecommendPagerAdapter(Context context, ArrayList<HashMap<String, Object>> data) {
		this.context = context;
		this.data = data;
		inflater = LayoutInflater.from(context);
	}

	@Override
	public Object instantiateItem(ViewGroup view, int position) {
		View views = inflater.inflate(R.layout.activity_paper_header_item, null);
		pageMap.put(position, views);
		view.addView(views);
		return views;
	}
}