package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wash.activity.R;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-7-16
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class OnlinePagerAdapter extends CommonPagerAdapter {

	public OnlinePagerAdapter(Context context, ArrayList<HashMap<String, Object>> data) {
		this.context = context;
		this.data = data;
		inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		return 10;
	}

	@Override
	public Object instantiateItem(ViewGroup view, int position) {
		View views = inflater.inflate(R.layout.activity_select_user_header_item, null);
		pageMap.put(position, views);
		view.addView(views);
		return views;
	}
}