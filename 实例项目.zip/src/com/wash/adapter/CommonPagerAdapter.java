package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * 通同viewpage适配器
 * @author gdpancheng@gmail.com 2013-10-28 上午11:06:08
 */
public class CommonPagerAdapter extends PagerAdapter {

	protected LayoutInflater inflater;
	protected Context context;
	/**组件集合**/
	protected HashMap<Integer, View> pageMap = new HashMap<Integer, View>();
	/**数据集合**/
	protected ArrayList<HashMap<String, Object>> data;
	
	@Override
	public int getCount() {
		return Integer.MAX_VALUE;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}

	@Override
	public void destroyItem(ViewGroup view, int position, Object object) {
		if (pageMap.containsKey(position)) {
			pageMap.remove(position);
			view.removeView(pageMap.get(position));
		}
	}
}
