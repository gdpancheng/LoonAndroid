package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.wash.activity.R;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-5-8
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class QuestionAdapter extends CommonAdapter {

	private LayoutInflater inflater;

	public QuestionAdapter(Context context, ArrayList<HashMap<String, Object>> data) {
		inflater = LayoutInflater.from(context);
		this.activity = context;
		this.data = data;
	}

	@Override
    public View view(int position, View convertView, ViewGroup parent) {
		convertView = inflater.inflate(R.layout.activity_question_item, null);
		TextView question_content = (TextView) convertView.findViewById(R.id.question_content);
		ImageView question_image = (ImageView) convertView.findViewById(R.id.question_image);
		question_content.setVisibility(View.VISIBLE);
		if (position == 1) {
			question_content.setVisibility(View.GONE);
			question_image.setVisibility(View.VISIBLE);
		}
		return convertView;
    }

}