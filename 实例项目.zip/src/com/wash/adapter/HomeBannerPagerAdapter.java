package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

import com.wash.activity.R;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-7-16
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class HomeBannerPagerAdapter extends CommonPagerAdapter {

	public HomeBannerPagerAdapter(Context context, ArrayList<HashMap<String, Object>> data) {
		this.context = context;
		this.data = data;
	}

	@SuppressWarnings("deprecation")
	public Object instantiateItem(ViewGroup view, int position) {
		ImageView imageView = new ImageView(context);
		imageView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
		imageView.setImageResource(R.drawable.demo3);
		imageView.setScaleType(ScaleType.FIT_XY);
		pageMap.put(position, imageView);
		view.addView(imageView);
		return imageView;
	}
}