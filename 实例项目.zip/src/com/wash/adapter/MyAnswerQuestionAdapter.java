package com.wash.adapter;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wash.activity.R;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-5-8
 * Copyright @ 2013 BU
 * Description: 类描述
 *
 * History:
 */
public class MyAnswerQuestionAdapter extends CommonAdapter {

	private LayoutInflater inflater;
	private int status = 0;

	public MyAnswerQuestionAdapter(Activity context, ArrayList<HashMap<String, Object>> data) {
		inflater = LayoutInflater.from(context);
		this.activity = context;
		this.data = data;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public View view(int position, View convertView, ViewGroup parent) {
		convertView = inflater.inflate(R.layout.activity_my_question_answer_item, null);
		TextView label = (TextView) convertView.findViewById(R.id.label);
		if (position % 3 == 0) {
			label.setVisibility(View.VISIBLE);
		}
		if (position % 3 == 1) {
			label.setTextColor(Color.RED);
		}

		if (position % 3 == 2) {
			label.setTextColor(activity.getResources().getColor(R.color.personal_text_color));
		}

		if (status == 1) {
			label.setTextColor(activity.getResources().getColor(R.color.personal_yellow));
		}

		if (status == 2) {
			label.setTextColor(Color.RED);
		}

		if (status == 3) {
			label.setTextColor(activity.getResources().getColor(R.color.personal_text_color));
		}
		return convertView;
	}

}