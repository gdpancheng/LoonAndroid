package com.wash.view;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.android.pc.ioc.app.Ioc;
import com.android.pc.util.Handler_System;
import com.wash.activity.R;
import com.wash.application.App;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2014-1-27
 * Copyright @ 2014 BU
 * Description: 类描述
 *
 * History:
 */
public class Progress extends LinearLayout {

	private int index = 0;
	private boolean run = false;

	public Progress(Context context) {
		super(context);
	}

	public Progress(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public void start() {
		setVisibility(View.VISIBLE);
		run = true;
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (run) {
					handler.sendEmptyMessage(0);
					try {
	                    Thread.sleep(100);
                    } catch (InterruptedException e) {
	                    e.printStackTrace();
                    }
				}
			}
		}).start();
	}

	public void end() {
		setVisibility(View.GONE);
		run = false;
	}

	private void add() {
		if (!run) {
			return;
		}
		index++;

		if (index > 20) {
			index = 0;
			removeAllViews();
			return;
		}

		ImageView imageView = new ImageView(getContext());
		LayoutParams layoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		imageView.setLayoutParams(layoutParams);
		layoutParams.leftMargin =  (int) (1.3*Handler_System.getWidthRoate());
		layoutParams.width = (int) (11*Handler_System.getWidthRoate());
		layoutParams.height = (int) (19*Handler_System.getWidthRoate());
		imageView.setImageResource(R.drawable.progress_bar);
		addView(imageView);
	}

	Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			add();
		}
	};

	protected void onDetachedFromWindow() {
		run = false;
	};
}
