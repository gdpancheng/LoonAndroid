package com.wash.application;

import android.app.Application;

import com.android.pc.ioc.app.Ioc;
import com.android.pc.util.Handler_SharedPreferences;

/*
 * Author: pan Email:gdpancheng@gmail.com
 * Created Date:2013-7-23
 * Copyright @ 2013 BU
 * Description: 全局application
 *
 * History:
 */
public class App extends Application {

	public static App app;
	
	
	@Override
	public void onCreate() {
		 app = this;
		Ioc.getIoc().init(this);
	    super.onCreate();
	}

	/**
	 * 数据存储到本地数据库
	 * 
	 * @author gdpancheng@gmail.com 2013-7-29 下午4:03:28
	 * @param key
	 * @param value
	 * @return void
	 */
	public void setData(String key, String value) {
		Handler_SharedPreferences.WriteSharedPreferences(getApplicationContext(), "Cache", key, value);
	}

	/**
	 * 取出本地数据
	 * 
	 * @author gdpancheng@gmail.com 2013-7-29 下午4:03:41
	 * @param key
	 * @return
	 * @return String
	 */
	public String getData(String key) {
		return Handler_SharedPreferences.getValueByName(getApplicationContext(), "Cache", key, Handler_SharedPreferences.STRING).toString();
	}
}
